# Tiktok-BOT
<a href="https://github.com/tahaluindo"><img src="https://i.ibb.co/vzSkDjZ/images-30.jpg" alt="images-30" border="0"></a>

This Tiktok BOT Tools Kit 

# Tentang Tiktok BOT

<a href="https://github.com/tahaluindo"><img src="https://i.ibb.co/7jRD1tj/images-31.jpg" alt="images-31" border="0"></a>

- Tiktok BOT Berbasis Python3 + Chrome Driver

# Cara Pasang Installer

<a href="https://github.com/tahaluindo"><img src="https://i.ibb.co/CPNFWHP/images-2.png" alt="images-2" border="0"></a>

- git clone https://github.com/tahaluindo/Tiktok-BOT

- cd Tiktok-BOT

- pip install selenium --upgrade

- python main.py

# Note

- Jika Tidak Work Lapor Ke Issue

- Add Massreporting Akun Tiktok 

# Support By

- Android On RDP 👍
- Windows 🎨
